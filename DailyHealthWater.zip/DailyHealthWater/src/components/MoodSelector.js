// src/components/MoodSelector.js
import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';

const moods = ['😊', '😐', '😔', '😡'];

export default function MoodSelector({ selectedMood, onSelectMood }) {
  return (
    <View style={styles.container}>
      <Text style={styles.label}>เลือกอารมณ์:</Text>
      <View style={styles.row}>
        {moods.map((mood, index) => (
          <TouchableOpacity
            key={index}
            style={[styles.moodButton, selectedMood === mood && styles.selected]}
            onPress={() => onSelectMood(mood)}
          >
            <Text style={styles.moodText}>{mood}</Text>
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { marginVertical: 20 },
  label: { fontSize: 18, marginBottom: 10, color: '#388e3c' },
  row: { flexDirection: 'row', justifyContent: 'space-around' },
  moodButton: {
    padding: 15,
    backgroundColor: '#c8e6c9',
    borderRadius: 10,
  },
  selected: {
    backgroundColor: '#81c784',
  },
  moodText: { fontSize: 24 },
});
