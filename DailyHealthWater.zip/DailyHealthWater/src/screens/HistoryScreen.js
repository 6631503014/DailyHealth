import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, Alert } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function HistoryScreen() {
  const [history, setHistory] = useState([]);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const data = await AsyncStorage.getItem('healthData');
      if (data) {
        setHistory(JSON.parse(data).reverse());
      }
    } catch (error) {
      console.error('Error loading data:', error);
    }
  };

  const deleteEntry = async (index) => {
    Alert.alert(
      'ลบข้อมูล',
      'คุณต้องการลบข้อมูลนี้ใช่หรือไม่?',
      [
        { text: 'ยกเลิก', style: 'cancel' },
        { 
          text: 'ลบ', 
          style: 'destructive',
          onPress: async () => {
            try {
              // We need to get the original index from the reversed list
              const originalData = await AsyncStorage.getItem('healthData');
              if (originalData) {
                const dataArray = JSON.parse(originalData);
                const originalIndex = dataArray.length - 1 - index;
                
                dataArray.splice(originalIndex, 1);
                await AsyncStorage.setItem('healthData', JSON.stringify(dataArray));
                
                // Update the displayed list
                setHistory(dataArray.reverse());
              }
            } catch (error) {
              console.error('Error deleting data:', error);
            }
          }
        }
      ]
    );
  };

  const getMoodEmoji = (mood) => {
    const moodEmojis = {
      'ดีมาก': '😄',
      'ดี': '🙂',
      'ปานกลาง': '😐',
      'แย่': '😔',
      'แย่มาก': '😣'
    };
    return moodEmojis[mood] || '❓';
  };

  const formatDate = (dateString) => {
    if (!dateString) return '';
    
    try {
      const date = new Date(dateString);
      return date.toLocaleDateString('th-TH', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        weekday: 'long'
      });
    } catch (error) {
      return dateString;
    }
  };

  const renderWaterDrops = (count) => {
    const drops = [];
    const maxVisibleDrops = 5;
    
    for (let i = 0; i < Math.min(count, maxVisibleDrops); i++) {
      drops.push(
        <Text key={i} style={styles.waterDrop}>💧</Text>
      );
    }
    
    if (count > maxVisibleDrops) {
      drops.push(
        <Text key="more" style={styles.waterDropMore}>+{count - maxVisibleDrops}</Text>
      );
    }
    
    return drops;
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>ประวัติสุขภาพย้อนหลัง</Text>
      </View>
      
      {history.length === 0 ? (
        <View style={styles.emptyState}>
          <Text style={styles.emptyStateText}>ไม่พบข้อมูลประวัติ</Text>
          <Text style={styles.emptyStateSubtext}>เริ่มบันทึกสุขภาพประจำวันของคุณ</Text>
        </View>
      ) : (
        <FlatList
          data={history}
          keyExtractor={(item, index) => index.toString()}
          renderItem={({ item, index }) => (
            <View style={styles.card}>
              <View style={styles.cardHeader}>
                <Text style={styles.dateText}>{formatDate(item.date)}</Text>
                <TouchableOpacity 
                  style={styles.deleteButton}
                  onPress={() => deleteEntry(index)}
                >
                  <Text style={styles.deleteButtonText}>🗑️</Text>
                </TouchableOpacity>
              </View>
              
              <View style={styles.divider} />
              
              <View style={styles.cardContent}>
                <View style={styles.moodContainer}>
                  <Text style={styles.dataLabel}>อารมณ์:</Text>
                  <View style={styles.moodDisplay}>
                    <Text style={styles.moodEmoji}>{getMoodEmoji(item.mood)}</Text>
                    <Text style={styles.moodText}>{item.mood}</Text>
                  </View>
                </View>
                
                <View style={styles.waterContainer}>
                  <Text style={styles.dataLabel}>น้ำดื่ม:</Text>
                  <View style={styles.waterDisplay}>
                    <Text style={styles.waterText}>{item.water} แก้ว</Text>
                    <View style={styles.waterDropsContainer}>
                      {renderWaterDrops(item.water)}
                    </View>
                  </View>
                </View>
              </View>
            </View>
          )}
          contentContainerStyle={styles.listContent}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f1f8e9',
  },
  header: {
    backgroundColor: '#558b2f',
    paddingTop: 50,
    paddingBottom: 15,
    paddingHorizontal: 20,
    borderBottomLeftRadius: 20,
    borderBottomRightRadius: 20,
    marginBottom: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  title: {
    fontSize: 22,
    fontWeight: 'bold',
    color: 'white',
    textAlign: 'center',
  },
  listContent: {
    padding: 15,
  },
  card: {
    backgroundColor: 'white',
    borderRadius: 15,
    marginBottom: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
    overflow: 'hidden',
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 15,
    backgroundColor: '#e8f5e9',
  },
  dateText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#2e7d32',
  },
  deleteButton: {
    padding: 5,
  },
  deleteButtonText: {
    fontSize: 18,
  },
  divider: {
    height: 1,
    backgroundColor: '#e0e0e0',
  },
  cardContent: {
    padding: 15,
  },
  moodContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  waterContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  dataLabel: {
    fontSize: 16,
    fontWeight: 'bold',
    width: 80,
    color: '#558b2f',
  },
  moodDisplay: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  moodEmoji: {
    fontSize: 24,
    marginRight: 8,
  },
  moodText: {
    fontSize: 16,
    color: '#333',
  },
  waterDisplay: {
    flex: 1,
  },
  waterText: {
    fontSize: 16,
    color: '#333',
    marginBottom: 5,
  },
  waterDropsContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  waterDrop: {
    fontSize: 16,
    marginRight: 2,
  },
  waterDropMore: {
    fontSize: 14,
    color: '#0277bd',
    marginLeft: 2,
  },
  emptyState: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 20,
  },
  emptyStateText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#558b2f',
    marginBottom: 8,
  },
  emptyStateSubtext: {
    fontSize: 16,
    color: '#7cb342',
    textAlign: 'center',
  }
});