import React, { useState, useEffect } from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';
import * as Notifications from 'expo-notifications';

export default function SettingsScreen() {
  const [reminderSet, setReminderSet] = useState(false);

  useEffect(() => {
    // ขออนุญาตการใช้งานการแจ้งเตือน
    Notifications.requestPermissionsAsync();
  }, []);

  const setWaterReminder = async () => {
    await Notifications.scheduleNotificationAsync({
      content: {
        title: "💧 ถึงเวลาดื่มน้ำ! 💧",
        body: "ดื่มน้ำเพื่อสุขภาพที่ดีนะครับ",
      },
      trigger: {
        seconds: 60 * 60, // ตั้งให้แจ้งเตือนทุก 1 ชั่วโมง
        repeats: true, // ทำให้แจ้งเตือนซ้ำทุกๆ 1 ชั่วโมง
      },
    });
    setReminderSet(true);
  };

  const cancelReminder = async () => {
    await Notifications.cancelAllScheduledNotificationsAsync();
    setReminderSet(false);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>🕒 ตั้งค่าการแจ้งเตือนดื่มน้ำ</Text>
      <Text style={styles.description}>
        {reminderSet
          ? 'การแจ้งเตือนดื่มน้ำได้รับการตั้งค่าแล้ว 💧'
          : 'ตั้งค่าการแจ้งเตือนดื่มน้ำ เพื่อสุขภาพที่ดี'}
      </Text>
      <Button
        title={reminderSet ? 'ยกเลิกการแจ้งเตือน 🚫' : 'ตั้งการแจ้งเตือนดื่มน้ำ 💦'}
        onPress={reminderSet ? cancelReminder : setWaterReminder}
        color="#4caf50"
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f9fbe7',
    justifyContent: 'center', // จัดให้อยู่กลางในแนวตั้ง
    alignItems: 'center',     // จัดให้อยู่กลางในแนวนอน
    padding: 20,
  },
  title: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#689f38',
    marginBottom: 15,
  },
  description: {
    fontSize: 16,
    color: '#4caf50',
    marginVertical: 10,
    textAlign: 'center',
  },
});
