import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Alert, SafeAreaView } from 'react-native';
import MoodSelector from '../components/MoodSelector';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function HomeScreen() {
  const [mood, setMood] = useState(null);
  const [waterCount, setWaterCount] = useState(0);
  
  const handleSave = async () => {
    const today = new Date().toISOString().split('T')[0];
    const entry = { mood, water: waterCount, date: today };
    
    try {
      const existing = await AsyncStorage.getItem('healthData');
      const data = existing ? JSON.parse(existing) : [];
      data.push(entry);
      await AsyncStorage.setItem('healthData', JSON.stringify(data));
      Alert.alert('สำเร็จ', 'บันทึกข้อมูลแล้ว!');
      setMood(null);
      setWaterCount(0);
    } catch (error) {
      console.error(error);
    }
  };
  
  return (
    <View style={styles.container}>
      <SafeAreaView style={styles.safeArea}>
        <View style={styles.header}>
          <Text style={styles.headerText}>บันทึกสุขภาพประจำวัน</Text>
        </View>
        
        <View style={styles.card}>
          <Text style={styles.title}>วันนี้คุณรู้สึกยังไงบ้าง?</Text>
          <MoodSelector selectedMood={mood} onSelectMood={setMood} />
        </View>
        
        <View style={styles.card}>
          <Text style={styles.waterTitle}>การดื่มน้ำของคุณ</Text>
          
          <View style={styles.waterTracker}>
            <View style={styles.waterInfo}>
              <Text style={styles.waterCount}>{waterCount}</Text>
              <Text style={styles.waterUnit}>แก้ว</Text>
            </View>
            
            <View style={styles.waterIconContainer}>
              {[...Array(Math.min(8, waterCount))].map((_, index) => (
                <Text key={index} style={styles.waterDrop}>💧</Text>
              ))}
            </View>
          </View>
          
          <TouchableOpacity 
            style={styles.addWaterButton}
            onPress={() => setWaterCount(waterCount + 1)}
          >
            <Text style={styles.addWaterButtonText}>เพิ่มน้ำ 1 แก้ว 💧</Text>
          </TouchableOpacity>
        </View>
        
        <TouchableOpacity 
          style={styles.saveButton}
          onPress={handleSave}
        >
          <Text style={styles.saveButtonText}>บันทึกข้อมูลวันนี้</Text>
        </TouchableOpacity>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#e8f5e9',
  },
  safeArea: {
    flex: 1,
    padding: 16,
  },
  header: {
    marginBottom: 24,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(0,0,0,0.1)',
  },
  headerText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#1b5e20',
    textAlign: 'center',
  },
  card: {
    backgroundColor: 'white',
    borderRadius: 16,
    padding: 20,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  title: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#388e3c',
    textAlign: 'center',
    marginBottom: 20,
  },
  waterTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#388e3c',
    marginBottom: 16,
  },
  waterTracker: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  waterInfo: {
    flexDirection: 'row',
    alignItems: 'baseline',
  },
  waterCount: {
    fontSize: 36,
    fontWeight: 'bold',
    color: '#0277bd',
  },
  waterUnit: {
    fontSize: 18,
    color: '#0277bd',
    marginLeft: 4,
  },
  waterIconContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    maxWidth: '60%',
  },
  waterDrop: {
    fontSize: 20,
    marginHorizontal: 2,
  },
  addWaterButton: {
    backgroundColor: '#29b6f6',
    borderRadius: 12,
    paddingVertical: 12,
    alignItems: 'center',
    marginTop: 8,
  },
  addWaterButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  saveButton: {
    backgroundColor: '#2e7d32',
    borderRadius: 12,
    paddingVertical: 16,
    alignItems: 'center',
    marginTop: 16,
  },
  saveButtonText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
  },
});